this is my first year python project based on image processing
